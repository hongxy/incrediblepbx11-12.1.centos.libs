<?php
/*
  =========================================================
   Contributed by Kennon Software's - Open Source Projects
   to the PBX-in-a-Flash Community (June 2008)

   Release: v3.0
   Supports: AAH v1.x - V2.x / TrixBox v1.x / PBIAF v1.x

   More info can be found at: http://www.kennonsoft.org/ 
  =========================================================
*/


// Load array of components
if (file_exists("welcome/.htindex.cfg")) {
	// Read configuration
	$fp = fopen("welcome/.htindex.cfg", "r");
	if ($fp) {
		while (!feof($fp)) {
			$buffer = fgets($fp);
			$arrBuffer = split(",",$buffer);
			$arrBuffer[2] = str_replace("$"."host", $host, $arrBuffer[2]); 			// $host variable substitutions for local URL entries
			$arr[$arrBuffer[1]] = $arrBuffer[2];							// File/URL path
			$arrUI[$arrBuffer[1]] = array($arrBuffer[0],$arrBuffer[3],$arrBuffer[4],true);	// UI row priority, Label, Icon, User-menu display (T/F)
		}
		fclose($fp);
	}
}

// Handle Form post processing if applicable
$post_success = "";
if (array_key_exists("_submit", $_POST)) {
	// Write configuration
	$fp = fopen("welcome/.htindex.dat", "w");
	if ($fp) {
		if ($_POST["users"] == "on") {
			$inputString = "users,";
		} else {
			$inputString = "admin,";
		}
		$inputString .= $_POST["pwd"].",";
		$inputString .= $_POST["rss"].",";
		if ($_POST["wrapper"] == "on") {
			$inputString .="true,";
		} else {
			$inputString .="false,";
		}

		foreach ($arr as $key => $value) {
			$tmp = "";
			foreach ($_POST["options"] as $key2 => $value2) {
				if ($value2 == $key) {
					$tmp = $value2.",";
				}
			}

			if ($tmp != "") {
				$inputString .= $tmp;
			} else {
				$inputString .= ",";
			}
		}
		$inputString = substr($inputString,0,strlen($inputString)-1);

		fwrite($fp, $inputString);
		fclose($fp);

		$post_success = "<span style=\"color:#ff0000\">Changes saved successfully!</span>";
	} else {
		echo "Please set file access to allow writing for this feature to operate correctly!";
		exit;
	}
}

// Configure display experience
$uimode = "admin";
$wrapper = false;
if (file_exists("welcome/.htindex.dat")) {
	// Read configuration
	$fp = fopen("welcome/.htindex.dat", "r");
	if ($fp) {
		$uiconfigstr = fread($fp, filesize("welcome/.htindex.dat"));
		$uiconfig = split(",",$uiconfigstr);
		fclose($fp);
		if (strtolower($uiconfig[0]) == "users") {
			$uimode = "users";
		}
		if (strtolower($uiconfig[3]) == "true") {
			$wrapper = true;
		}
	}
}

// If in "users" mode & Admin request, verify optional password
if (($uimode == "users") && ($uiconfig[1] != "")) {
	// Verify password in cookie
	if ($_COOKIE["ksc-menu"] != "0x123") {
		header("Location: index.php?pg=2");
		exit;
	}
}

// RSS Feed Fetch & Format
$htmlRSS = "";
$rss =  simplexml_load_file($uiconfig[2]);
foreach ($rss->channel->item as $item) {
	$htmlRSS .= '					<a href="'.$item->link.'" target="_rss">'.$item->title."</a><br/>"."\n";
	$htmlRSS .= $item->description."<br/><br/>"."\n";
}
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
	<title>:: Dynamic UI : Menus Configuration</title>

	<meta http-equiv="imagetoolbar" content="no" />
	<meta name="MSSmartTagsPreventParsing" content="true" />
	<meta name="author" content="Kennon Software Corporation" />
	<meta name="powered-by" content="http://www.kennonsoft.org" />
	<meta http-equiv="Content-Type" content="text/html">
	
	<link rel="shortcut icon" href="favicon.ico" />
	<link rel="stylesheet" href="welcome/m_styles.css" type="text/css"/>
	<script type="text/javascript" src="welcome/scripts/mootools-12.js"></script>
	<script type="text/javascript" src="welcome/scripts/moolib.js"></script>
	<script>
		window.addEvent('domready', function(){
			$('brand_users').setStyle('display','none');
			$('brand_admin').setStyle('display','block');

			// RSS Scrolling enable
			new MooScroller('content', 'scrollKnob');
		});
	</script>
</head>
<body>
	<div id="wrapper">
		<div id="left">
		
			<!-- LEFT COLUMN CONTENT -->
			<div id="logo"><a href="http://www.pbxinaflash.com/" target="_new" title="(Popup) PBX in a Flash website!"><img src="welcome/pt.gif" width="150" height="120" border="0"/></a></div>
<?
   if ($htmlRSS != "") {
?>
			<div id="rss">
				<div id="scroller">
					<div id="content">
<? echo $htmlRSS; ?>
					</div>
					<div id="scrollarea">
						<div id="scrollBack"></div>
						<div id="scrollBarContainer">
							<div id="scrollKnob"></div>
						</div>
						<div id="scrollForward"></div>
					</div>
				</div>
			</div>
<?
   }
?>
		</div>

		<div id="right">

			<!-- RIGHT COLUMN CONTENT -->

			<div id="admin">
				<div id="buttons">
					<div id="config">
						<p>&nbsp;<? echo $post_success ?></p>

						<form action="config.php" method="post">
							<input type="hidden" name="_submit" value="1" />
							<input type="checkbox" name="users"<? if ($uimode == "users") { echo "checked=\"true\""; } ?>>Enable End-user Menu</input><br />
							&nbsp;<br />
							<select name="options[]" size="10" multiple="true" style="width:185px">
<? 
// Load selections
$counter = 1;
foreach ($arr as $key => $value) {
	if ($arrUI[$key][0] < 4) {
		if (strpos($uiconfigstr, $key)) {
			echo "<option value=\"".$key."\" selected>".$arrUI[$key][1]."</option><br />";
		} else {
			echo "<option value=\"".$key."\">".$arrUI[$key][1]."</option><br />";
		}
	}
}
?>
							</select><br />
							&nbsp;<br />
							<input type="checkbox" name="wrapper"<? if ($wrapper) { echo "checked=\"true\""; } ?>>Use Menu Wrapper</input><br />
							&nbsp;<br />
							Admin Pwd:&nbsp;<input type="password" name="pwd" value="<? echo $uiconfig[1] ?>" style="width:100px" /><br />
							&nbsp;<br />
							RSS URL:&nbsp;<input type="text" name="rss" value="<? echo $uiconfig[2] ?>" style="width:107px" /><br />
							&nbsp;<br />
							<input type="submit" value="   Update   " />&nbsp;&nbsp;<input type="button" value="  Done  " onclick="javascript:window.location.href='index.php<? if ($uimode == "users") { echo "?pg=2"; } ?>';"/>
						</form>
					</div>
				</div>
			</div>
			<div id="branding">

<?php include("_branding.htm"); ?>

			</div>
		</div>
		<a class="credits" href="http://www.kennonsoft.org/" target="_new" title="(Popup) Kennon Software Open Source website!">DynamicUI v3.0, &copy; Kennon Software Corporation</a>
	</div>
</body>
</html>