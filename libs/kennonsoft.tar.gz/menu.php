<?php
/*
  =========================================================
   Contributed by Kennon Software's - Open Source Projects
   to the PBX-in-a-Flash Community (June 2008)

   Release: v3.0
   Supports: AAH v1.x - V2.x / TrixBox v1.x / PBIAF v1.x

   More info can be found at: http://www.kennonsoft.org/ 
  =========================================================
*/


// Default values
error_reporting(E_ALL ^ E_NOTICE);
$host = $_SERVER['HTTP_HOST'];
if (strpos($host,":")>0) :
	$host = substr($host,0,strpos($host,":")) ;
endif ;
$id = $_REQUEST["id"];

// Load array of components
if (file_exists("welcome/.htindex.cfg")) {
	// Read configuration
	$fp = fopen("welcome/.htindex.cfg", "r");
	if ($fp) {
		while (!feof($fp)) {
			$buffer = fgets($fp);
			$buffer = str_replace("\n", "", $buffer);
			$arrBuffer = explode(",",$buffer);
			$arrBuffer[2] = str_replace("$"."host", $host, $arrBuffer[2]); 			// $host variable substitutions for local URL entries
			$arr[$arrBuffer[1]] = $arrBuffer[2];							// File/URL path
			$arrUI[$arrBuffer[1]] = array($arrBuffer[0],$arrBuffer[3],$arrBuffer[4],true);	// UI row priority, Label, Icon, User-menu display (T/F)
		}
		fclose($fp);
	}
}

?>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title><?php echo $arrUI[$id][1] ?></title>
</head>
<frameset rows="27,*">
	<frame src="_wrapper.htm" frameborder="0" noresize="true" scrolling="no" marginwidth="0" marginheight="0">
	<frame src="<?php echo $arr[$id] ?>" frameborder="0">
	<noframes>
		<script>window.location.href='<?php echo $arr[$id] ?>';</script>
	</noframes>
</frameset>
</html>
