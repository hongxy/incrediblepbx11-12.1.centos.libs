/*MooTools, My Object Oriented Javascript Tools. Copyright (c) 2006-2007 Valerio Proietti, <http://mad4milk.net>, MIT Style License.||CNET Libraries Copyright (c) 2006-2008, http://clientside.cnet.com/wiki/cnet-libraries#license*/

var MooScroller=new Class({Implements:[Options,Events],options:{maxThumbSize:10,mode:'vertical',width:0,scrollSteps:10,wheel:true,scrollLinks:{forward:'scrollForward',back:'scrollBack'}},initialize:function(content,knob,options){this.setOptions(options);this.horz=(this.options.mode=="horizontal");this.content=$(content).setStyle('overflow','hidden');this.knob=$(knob);this.track=this.knob.getParent();this.setPositions();if(this.horz&&this.options.width){this.wrapper=new Element('div');this.content.getChildren().each(function(child){this.wrapper.adopt(child)});this.wrapper.inject(this.content).setStyle('width',this.options.width)}this.bound={'start':this.start.bind(this),'end':this.end.bind(this),'drag':this.drag.bind(this),'wheel':this.wheel.bind(this),'page':this.page.bind(this)};this.position={};this.mouse={};this.update();this.attach();var clearScroll=function(){$clear(this.scrolling)}.bind(this);['forward','back'].each(function(direction){var lnk=$(this.options.scrollLinks[direction]);if(lnk){lnk.addEvents({mousedown:function(){this.scrolling=this[direction].periodical(50,this)}.bind(this),mouseup:clearScroll.bind(this),click:clearScroll.bind(this)})}},this);this.knob.addEvent('click',clearScroll.bind(this));window.addEvent('domready',function(){try{$(document.body).addEvent('mouseup',clearScroll.bind(this))}catch(e){}}.bind(this))},setPositions:function(){[this.track,this.knob].each(function(el){if(el.getStyle('position')=='static')el.setStyle('position','relative')})},toElement:function(){return this.content},update:function(){var plain=this.horz?'Width':'Height';this.contentSize=this.content['offset'+plain];this.contentScrollSize=this.content['scroll'+plain];this.trackSize=this.track['offset'+plain];this.contentRatio=this.contentSize/this.contentScrollSize;this.knobSize=(this.trackSize*this.contentRatio).limit(this.options.maxThumbSize,this.trackSize);this.scrollRatio=this.contentScrollSize/this.trackSize;this.knob.setStyle(plain.toLowerCase(),this.knobSize);this.updateThumbFromContentScroll();this.updateContentFromThumbPosition()},updateContentFromThumbPosition:function(){this.content[this.horz?'scrollLeft':'scrollTop']=this.position.now*this.scrollRatio},updateThumbFromContentScroll:function(){this.position.now=(this.content[this.horz?'scrollLeft':'scrollTop']/this.scrollRatio).limit(0,(this.trackSize-this.knobSize));this.knob.setStyle(this.horz?'left':'top',this.position.now)},attach:function(){this.knob.addEvent('mousedown',this.bound.start);if(this.options.scrollSteps)this.content.addEvent('mousewheel',this.bound.wheel);this.track.addEvent('mouseup',this.bound.page)},wheel:function(event){this.scroll(-(event.wheel*this.options.scrollSteps));this.updateThumbFromContentScroll();event.stop()},scroll:function(steps){steps=steps||this.options.scrollSteps;this.content[this.horz?'scrollLeft':'scrollTop']+=steps;this.updateThumbFromContentScroll();this.fireEvent('onScroll',steps)},forward:function(steps){this.scroll(steps)},back:function(steps){steps=steps||this.options.scrollSteps;this.scroll(-steps)},page:function(event){var axis=this.horz?'x':'y';var forward=(event.page[axis]>this.knob.getPosition()[axis]);this.scroll((forward?1:-1)*this.content['offset'+(this.horz?'Width':'Height')]);this.updateThumbFromContentScroll();this.fireEvent('onPage',forward);event.stop()},start:function(event){var axis=this.horz?'x':'y';this.mouse.start=event.page[axis];this.position.start=this.knob.getStyle(this.horz?'left':'top').toInt();document.addEvent('mousemove',this.bound.drag);document.addEvent('mouseup',this.bound.end);this.knob.addEvent('mouseup',this.bound.end);event.stop()},end:function(event){document.removeEvent('mousemove',this.bound.drag);document.removeEvent('mouseup',this.bound.end);this.knob.removeEvent('mouseup',this.bound.end);event.stop()},drag:function(event){var axis=this.horz?'x':'y';this.mouse.now=event.page[axis];this.position.now=(this.position.start+(this.mouse.now-this.mouse.start)).limit(0,(this.trackSize-this.knobSize));this.updateContentFromThumbPosition();this.updateThumbFromContentScroll();event.stop()}});

/* IE PNG FIX - MooTools detect IE6 plus CSS updateability (Kennon Software - Library, 2008)
   ================================================================================= */
if (Browser.Engine.trident4 && document.all && document.styleSheets && document.styleSheets[0] && document.styleSheets[0].addRule) {
	window.addEvent('domready', function(){
		document.styleSheets[0].addRule('img', 'behavior: url(welcome/scripts/nm_iepngfix.htc)');
	});
}

/*
 @description		MooTools based iPhonesque switch button
 @author			Marcel Miranda Ackerman < reaktivo.com >
 @license 			MIT Style License.
 @version			0.6
 @date			2008-04-02
 @dependencies		mootools 1.2b
 
 @CUSTOM		Kennon Software Corporation on 6/9/2008
 @CUSTOM		(Added "updated" event to allow optional client-side interactions)
*/
var mooSwitch = new Class({
	Implements: Events, // KSC: Implement events
	Extends: Drag.Move,
	initialize: function(radios, params){
		params = params || [];
		this.duration = params.duration || 100;
		this.hide_radios = (params.hide_radios != undefined) ? params.hide_radios : true;
		this.hide_labels = (params.hide_labels != undefined) ? params.hide_labels : false;
		this.label_position = (params.label_position != undefined) ? params.label_position : 'outside';
		this.drag_opacity = (params.drag_opacity != undefined) ? params.drag_opacity : 1;
		this.mouse_over_handle = false;
		
		this.is_dragging = false;
		if(this.label_position == 'outside' && params.label_bg == undefined){
			this.label_bg = 'light';
		}else{
			this.label_bg = (params.label_bg != undefined) ? params.label_bg : 'dark';
			//console.log(this.label_bg);
		}
		this.mvalue = 0;
		
		//Create Elements
		this.container = new Element('div', {'class':'switchbox'});
		this.scrollarea = new Element('div', {'class':'scrollarea'}).inject(this.container);
		this.handle = new Element('div', {'class':'handle'}).inject(this.scrollarea);
		this.handle.setStyle('z-index', 1);
		this.left_label = new Element('div', {'class':'label left'}).inject(this.container);
		this.right_label = new Element('div', {'class':'label right'}).inject(this.container);
		this.labels = this.container.getElements('.label');
		
		//Hide Radioboxes and Labels
		this.radio_el = $$('input[name='+radios+']');
		this.container.inject(this.radio_el[this.radio_el.length-1], 'after');
		
		if(this.label_bg == 'light'){
			this.labels.addClass('light_bg');
		}
		if(this.label_position=='outside'){
			this.container.setStyle('width', this.left_label.getStyle('width').toInt() + this.scrollarea.getStyle('width').toInt() + this.right_label.getStyle('width').toInt());
			this.scrollarea.setStyle('left', this.left_label.getStyle('width').toInt());
			this.scrollarea.setStyle('cursor', 'pointer');
			this.scrollarea.addEvent('click', function(){
				if(!this.mouse_over_handle) {
					if(this.mvalue==0){
						this.mvalue = 1;
					}else{
						this.mvalue = 0;
					}
					this.goTo(this.mvalue);
				}
			}.bind(this));
		}else{
			this.container.setStyle('width', this.scrollarea.getStyle('width').toInt());	
		}
		
		this.maxscroll = this.scrollarea.getStyle('width').toInt() - this.handle.getStyle('width').toInt();
		this.radio_el.each(function(item,index){
			if(this.hide_radios) {
				item.setStyle('display', 'none');
				$$('label[for=' + item.get('id') + ']').setStyle('display', 'none');
			}
			
			if(item.checked == true) this.goTo.bind(this, [index, 0])();
			var opttext = $$('label[for=' + item.get('id') + ']')[0].get('text');
			this.container.getElements('.label')[index].set('text', opttext);
			//console.log(this.container.getElements('.label')[index].get('text'));
		
		}.bind(this));
		
		//Execute Drag.Move initialize function
		this.parent(this.handle, {
			container: this.scrollarea,
			onStart: function (){
				this.is_dragging = true;
				this.handle.morph({'opacity': this.drag_opacity});
			},
			onComplete: function (){
				
				if(this.handle.getStyle('left').toInt() < this.maxscroll/2){
					this.goTo(0);
				}else{
					this.goTo(1);
				}
			}
		});
		
		//Set Events
		this.left_label.addEvent('click', this.goTo.bind(this, [0]));
		this.right_label.addEvent('click', this.goTo.bind(this, [1]));
		
		this.handle.addEvent('mouseover', function(){
			this.mouse_over_handle = true;
		}.bind(this));
		this.handle.addEvent('mouseout', function(){
			this.mouse_over_handle = false;
		}.bind(this));
		
		if(this.hide_labels){
			this.labels.setStyle('display', 'none');
		}
	},
	goTo: function(value, duration){
		var cursor = (value==0) ? 'e-resize' : 'w-resize';
		this.handle.setStyle('cursor', cursor);
		duration = duration || this.duration;
		this.handle.set('morph', {duration:duration});
		this.handle.morph({
			'left' : this.maxscroll*value,
			'opacity' : 1
		});
		
		this.mvalue = value;
		this.radio_el[value].checked = true;
		
		// KSC: Notify client of changes
		this.fireEvent('updated', this.mvalue);
	}
});