#!/bin/bash

# Copyright (C) 2012, Ward Mundy. All Rights Reserved.

clear
echo "In order to properly configure Wolfram Alpha, we need some info."
echo "None of this information is stored anywhere except on this machine!"
echo " "
echo "1. Wolfram Alpha APP-ID"
echo "   This is the application ID code issued by Wolfram Alpha when you"
echo "   signed up at http://developer.wolframalpha.com/portal/apisignup.html"
echo " "
echo " "

echo "If you're missing this information, press Ctrl-C to abort now."
read -p "To proceed at your own risk, press the Enter key."

clear
echo -n "Your Wolfram Alpha APP-ID code: "
read pwmaster
echo "Wolfram Alpha APP-ID: $pwmaster"

echo " "
echo "By using Wolfram Alpha for Asterisk, YOU AGREE TO ASSUME ALL RESPONSIBILITY"
echo "FOR USE OF THE PROGRAMS INCLUDED IN THIS INSTALLATION. NO WARRANTIES"
echo "EXPRESS OR IMPLIED INCLUDING MERCHANTABILITY AND FITNESS FOR PARTICULAR"
echo "USE ARE PROVIDED. YOU ASSUME ALL RISKS KNOWN AND UNKNOWN AND AGREE TO"
echo "HOLD WARD MUNDY, Ward Mundy & Associates, NERD VITTLES, AND THE PBX IN"
echo "A FLASH DEVELOPMENT TEAM HARMLESS FROM ANY AND ALL LOSS OR DAMAGE"
echo "WHICH RESULTS FROM YOUR USE OF THIS SOFTWARE. IF ANY OF THESE TERMS"
echo "AND CONDITIONS ARE RULED TO BE UNENFORCEABLE, YOU AGREE TO ACCEPT ONE"
echo "DOLLAR IN U.S. CURRENCY AS COMPENSATORY AND PUNITIVE LIQUIDATED DAMAGES"
echo "FOR ANY AND ALL CLAIMS YOU MIGHT HAVE."
echo " "

echo "If you do not agree with these terms and conditions of use, press Ctrl-C now."
read -p "Otherwise, press Enter to proceed at your own risk..."

clear
echo "Installing The Incredible PBX. Please wait. This installer runs unattended."
echo "Consider a donation to Nerd Vittles while you're waiting. Return in 15 minutes."
echo "Do NOT press any keys while the installation is underway. Be patient!"
echo " "

echo "Skipping Google transcription middleware..."
#cd /root
#wget --no-check-certificate http://nerd.bz/w8HCDF
#tar zxvf asterisk-speech*
#cd asterisk-speech-recog-0.4
#cp speech-recog.agi /var/lib/asterisk/agi-bin/.
#cd samples
#cp speech-recog-cli.pl /usr/local/sbin/.

echo " "
echo "Installing Wolfram Alpha middleware..."
cd /
wget http://nerd.bz/A7umMK
tar zxvf 4747.tgz
rm 4747.tgz
sed -i '/\[from-internal-custom\]/r /tmp/4747.txt' /etc/asterisk/extensions_custom.conf
asterisk -rx "dialplan reload"

echo " "
echo "Installing your Wolfram Alpha APP-ID..."
sed -i 's|yourID|'$pwmaster'|' /var/lib/asterisk/agi-bin/4747

echo " "
echo "Installing perl-XML-Simple for future use..."
yum -y install perl-XML-Simple

clear
echo " "
echo "Installation has completed."
echo "Wolfram Alpha access is now available on your system."
echo "Just pick up any phone and dial 4-7-4-7." 
echo "For details, visit: http://nerdvittles.com/?p=798"
echo " "
echo " "

