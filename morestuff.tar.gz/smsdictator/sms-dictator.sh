#!/bin/bash

# The SMS Dictator © Copyright 2002, Ward Mundy & Associates
# This software is distributed subject to the

clear
if [ -e "/usr/bin/gvoice" ] ; then
 echo "The SMS Dictator installer is for PBX in a Flash 2 systems ONLY!"
 echo "SMS Dictator is free software provided AS IS subject to GPL2 license."
 echo "NEVER RUN THIS INSTALLER ON THE SAME SYSTEM MORE THAN ONCE!"
 else
 echo "WARNING: The SMS Dictator installer only works with PBX in a Flash 2."
 echo "You appear to be running an incompatible version. DO NOT PROCEED."
 exit
fi

echo " "
echo "YOU UNDERSTAND AND AGREE THAT YOU ARE RESPONSIBLE FOR"
echo "ALL TELECOMMUNICATIONS AND SMS CHARGES AND FEES WHICH"
echo "MAY BE IMPOSED UPON YOU AND OTHERS BY SENDING SMS MESSAGES!"
echo "BY USING THIS APP AND INSTALL SCRIPT, YOU AGREE TO ASSUME ALL RISKS."
echo "NO WARRANTY, EXPRESS OR IMPLIED, OF ANY KIND IS PROVIDED."
echo "THIS INCLUDES IMPLIED WARRANTIES OF FITNESS FOR USE AND MERCHANTABILITY."
echo " "

read -p "To proceed at your own risk, press Enter. Otherwise, Ctrl-C to abort."

clear
echo -n "Your dedicated Google Voice email address including @gmail.com: "
read gvname
echo "ACCTNAME: $gvname"
echo -n "Your Google Voice password: "
read gvpass
echo "ACCTPASS: $gvpass"

read -p "To proceed at your own risk, press Enter. Otherwise, Ctrl-C to abort."


echo "Skipping Google transcription middleware..."
#cd /root
#wget --no-check-certificate http://nerd.bz/w8HCDF
#tar zxvf asterisk-speech*
#cd asterisk-speech-recog-0.4
#cp speech-recog.agi /var/lib/asterisk/agi-bin/.
#cd samples
#cp speech-recog-cli.pl /usr/local/sbin/.

test=`grep gvoice /etc/sudoers`
if [ -z "$test" ]
then
 echo "asterisk ALL = NOPASSWD: /usr/bin/gvoice" >> /etc/sudoers
fi

cd /tmp
wget http://nerdvittles.com/wp-content/sms-dictator.txt

sed -i 's|11111|'$gvname'|' /tmp/sms-dictator.txt
sed -i 's|22222|'$gvpass'|' /tmp/sms-dictator.txt
sed -i '/\[from-internal-custom\]/r /tmp/sms-dictator.txt' /etc/asterisk/extensions_custom.conf
rm /tmp/sms-dictator.txt

asterisk -rx "dialplan reload"

echo "Installation completed. Dial S-M-S (767) to take SMS Dictator for a spin."

